# Maison Nike

Site de vente de baskets (HTML, CSS, JavaScript, sans serveur).

- `index.html` : structure de la page
- `style.css` : design
- `app.js` : catalogue, panier, commande (WhatsApp), compte, administration
- `images/` : photos des modèles

## Mettre en ligne (GitHub Pages)
1. Envoyez tout le contenu de ce dossier à la racine d'un dépôt GitHub.
2. Settings > Pages > Branch `main` > Save.

## Administration
Adresse du site suivie de `#admin`. Compte de démonstration : admin@maisonnike.cd / admin123
(à changer dans `app.js` avant la mise en ligne : voir la ligne `U=[{id:"admin"...`, le mot de passe est stocké haché en SHA-256 avec le sel `mn`).

## À savoir
Pas de base de données : commandes, comptes et messages restent dans le navigateur de chaque visiteur.
Numéro WhatsApp et paiement : constante `CONTACT` au début de `app.js`.
